import java.text.NumberFormat;
import java.util.Scanner;

public class mortgagecalculator {
    public static void main(String []arg){
        Scanner scanner = new Scanner(System.in);

        final int percent= 100;
        final int months = 12;
        int AmountOfLoan =0;
        float AnnualInterestRate=0;
        float MonthlyinterestRate=0;
        int  Year = 0;
        int NumberOfPayment=0;

/*-----------------------------------------------------------------------------------------*/

        //AmountOfLoan
        while(true)
        {
        System.out.println("Enter amount of loan: ");
         AmountOfLoan = scanner.nextInt();
         if(AmountOfLoan >=1000 && AmountOfLoan <=1_000_000)
           break;
         System.out.println("please enter value between $1k and $1M"); }

/*-----------------------------------------------------------------------------------------*/

        //MonthlyinterestRate
        while(true){
        System.out.println("Enter annual interst rate: ");
        AnnualInterestRate = scanner.nextInt();

        if(AnnualInterestRate >= 1 && AnnualInterestRate <=30)
        {
            MonthlyinterestRate = AnnualInterestRate/percent/months;
             break;}
        System.out.println("please enter value greater than zero");}

 /*-----------------------------------------------------------------------------------------*/
        while(true){
        System.out.println("Enter mortage period in year: ");
         Year = scanner.nextInt();
        if(Year>=1 && Year<=20){
             NumberOfPayment = Year*months;
            break;}
        System.out.println("please enter value greater between 1 and 20");  }


/*-----------------------------------------------------------------------------------------*/

        double mortgage = AmountOfLoan
                * (MonthlyinterestRate * Math.pow(1 + MonthlyinterestRate, NumberOfPayment))
                / (Math.pow(1 + MonthlyinterestRate, NumberOfPayment) - 1);

        String mortgageFormatted = NumberFormat.getCurrencyInstance().format(mortgage);
        System.out.println("Mortgage: " + mortgageFormatted);


    }
}
